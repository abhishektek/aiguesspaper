-- Create tutorial_videos table
CREATE TABLE public.tutorial_videos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  youtube_url TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.tutorial_videos ENABLE ROW LEVEL SECURITY;

-- Allow everyone to view active tutorial videos
CREATE POLICY "Anyone can view active tutorial videos"
ON public.tutorial_videos
FOR SELECT
USING (is_active = true);

-- Only authenticated users can manage tutorial videos (admin check will be in app layer)
CREATE POLICY "Authenticated users can insert tutorial videos"
ON public.tutorial_videos
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update tutorial videos"
ON public.tutorial_videos
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete tutorial videos"
ON public.tutorial_videos
FOR DELETE
TO authenticated
USING (true);