import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  icon: LucideIcon;
  value: number | string;
  label: string;
  iconColor: string;
}

const StatsCard = ({ icon: Icon, value, label, iconColor }: StatsCardProps) => {
  return (
    <Card className="p-4 flex items-center gap-3">
      <div className={`${iconColor} rounded-full p-2`}>
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-sm text-muted-foreground">{label}</p>
      </div>
    </Card>
  );
};

export default StatsCard;
