import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface QuickActionButtonProps {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  variant?: "primary" | "accent";
}

const QuickActionButton = ({ 
  icon: Icon, 
  label, 
  onClick,
  variant = "primary"
}: QuickActionButtonProps) => {
  const bgColor = variant === "accent" ? "bg-accent" : "bg-primary";
  
  return (
    <Card 
      className="p-6 flex flex-col items-center gap-3 cursor-pointer hover:shadow-lg transition-all"
      onClick={onClick}
    >
      <div className={`${bgColor} rounded-full p-3`}>
        <Icon className="h-6 w-6 text-white" />
      </div>
      <p className="text-sm font-medium text-foreground text-center">{label}</p>
    </Card>
  );
};

export default QuickActionButton;
