import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import AskQuestion from "./pages/AskQuestion";
import SelectUniversity from "./pages/SelectUniversity";
import SelectCourse from "./pages/SelectCourse";
import SelectSemester from "./pages/SelectSemester";
import SelectSubject from "./pages/SelectSubject";
import EnterQuestion from "./pages/EnterQuestion";
import HistoryPage from "./pages/HistoryPage";
import SavedPage from "./pages/SavedPage";
import ProfilePage from "./pages/ProfilePage";
import LoginPage from "./pages/LoginPage";
import DonatePage from "./pages/DonatePage";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<Dashboard />} />
          <Route path="/ask" element={<AskQuestion />} />
          <Route path="/ask/select-university" element={<SelectUniversity />} />
          <Route path="/select-course" element={<SelectCourse />} />
          <Route path="/select-semester" element={<SelectSemester />} />
          <Route path="/select-subject" element={<SelectSubject />} />
          <Route path="/enter-question" element={<EnterQuestion />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/saved" element={<SavedPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/donate" element={<DonatePage />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
