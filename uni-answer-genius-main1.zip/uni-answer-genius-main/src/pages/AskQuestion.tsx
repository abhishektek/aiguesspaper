import { useEffect } from "react";
import { ArrowLeft, MoreVertical } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";

const AskQuestion = () => {
  const navigate = useNavigate();

  // Redirect to university selection
  useEffect(() => {
    navigate("/ask/select-university");
  }, [navigate]);

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">Question Solver App (User)</h1>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <main className="flex items-center justify-center h-[calc(100vh-200px)]">
        <p className="text-muted-foreground">Redirecting...</p>
      </main>

      <BottomNav />
    </div>
  );
};

export default AskQuestion;
