import { ArrowLeft, GraduationCap, Building2, School, MoreVertical } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import BottomNav from "@/components/BottomNav";

const universities = [
  { id: "ppu", name: "Patliputra University (PPU)", icon: GraduationCap },
  { id: "magadh", name: "Magadh University", icon: Building2 },
  { id: "tmbu", name: "TMBU", icon: School },
  { id: "other", name: "Other University", icon: Building2 },
];

const SelectUniversity = () => {
  const navigate = useNavigate();

  const handleSelectUniversity = (universityId: string, universityName: string) => {
    navigate("/select-course", { state: { university: universityName } });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Top Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">Question Solver App (User)</h1>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Navigation Header */}
      <div className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h2 className="text-xl font-semibold text-foreground">Select University</h2>
          </div>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="px-6 py-8">
        <h3 className="text-2xl font-bold text-foreground mb-6">Select Your University</h3>
        
        <div className="space-y-4 mb-8">
          {universities.map((university) => (
            <Card
              key={university.id}
              className="p-5 flex items-center gap-4 cursor-pointer hover:shadow-lg transition-all active:scale-98"
              onClick={() => handleSelectUniversity(university.id, university.name)}
            >
              <div className="bg-accent/20 rounded-lg p-3">
                <university.icon className="h-6 w-6 text-accent" />
              </div>
              <h4 className="text-lg font-medium text-foreground">{university.name}</h4>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button
            variant="link"
            onClick={() => navigate("/")}
            className="text-primary"
          >
            ← Back to Dashboard
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default SelectUniversity;
