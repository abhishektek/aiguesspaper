import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, DollarSign, Bell, Users, Instagram, Youtube, Mail, LogOut, Link2, FileText, Video, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Textarea } from "@/components/ui/textarea";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalQuestions: 0,
    totalDonations: 0,
  });

  const [socialLinks, setSocialLinks] = useState({
    instagram: "https://instagram.com",
    youtube: "https://youtube.com",
    email: "contact@ppu.edu",
  });

  const [upiSettings, setUpiSettings] = useState({
    upiId: "abhishektek80@ybl",
    upiName: "PPU Question Solver",
  });

  const [legalLinks, setLegalLinks] = useState({
    privacyPolicy: "",
    termsOfService: "",
  });

  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");
  const [isSending, setIsSending] = useState(false);

  const [tutorialVideos, setTutorialVideos] = useState<any[]>([]);
  const [newVideo, setNewVideo] = useState({
    title: "",
    youtube_url: "",
    description: "",
  });

  useEffect(() => {
    checkAuth();
    fetchStats();
    loadSettings();
    fetchTutorialVideos();
  }, []);

  const loadSettings = () => {
    const savedSocialLinks = localStorage.getItem("socialLinks");
    const savedUpiSettings = localStorage.getItem("upiSettings");
    const savedLegalLinks = localStorage.getItem("legalLinks");
    
    if (savedSocialLinks) setSocialLinks(JSON.parse(savedSocialLinks));
    if (savedUpiSettings) setUpiSettings(JSON.parse(savedUpiSettings));
    if (savedLegalLinks) setLegalLinks(JSON.parse(savedLegalLinks));
  };

  const checkAuth = () => {
    const isAdmin = localStorage.getItem("adminAuth");
    if (!isAdmin) navigate("/admin/login");
  };

  const fetchStats = async () => {
    const { count: questionsCount } = await supabase
      .from("questions_history")
      .select("*", { count: "exact", head: true });

    const { data: { users } } = await supabase.auth.admin.listUsers();
    const totalUsers = users?.length || 0;

    const { data: donations } = await supabase.from("donations").select("amount");
    const totalDonations = donations?.reduce((sum, d) => sum + Number(d.amount), 0) || 0;

    setStats({ totalUsers, totalQuestions: questionsCount || 0, totalDonations });
  };

  const handleLogout = () => {
    localStorage.removeItem("adminAuth");
    toast.success("Logged out successfully");
    navigate("/admin/login");
  };

  const handleSaveSocialLinks = () => {
    localStorage.setItem("socialLinks", JSON.stringify(socialLinks));
    toast.success("Social links updated successfully!");
  };

  const handleSaveUpiSettings = () => {
    localStorage.setItem("upiSettings", JSON.stringify(upiSettings));
    toast.success("UPI settings updated successfully!");
  };

  const handleSaveLegalLinks = () => {
    localStorage.setItem("legalLinks", JSON.stringify(legalLinks));
    toast.success("Legal links updated successfully!");
  };

  const handleSendNotification = async () => {
    if (!notificationTitle.trim() || !notificationMessage.trim()) {
      toast.error("Please fill in both title and message");
      return;
    }

    setIsSending(true);
    try {
      const { data: { users }, error: usersError } = await supabase.auth.admin.listUsers();
      if (usersError) throw usersError;

      const notifications = users.map(user => ({
        user_id: user.id,
        title: notificationTitle,
        message: notificationMessage,
      }));

      const { error: notifError } = await supabase.from("notifications").insert(notifications);
      if (notifError) throw notifError;

      toast.success(`Notification sent to ${users.length} users!`);
      setNotificationTitle("");
      setNotificationMessage("");
    } catch (error: any) {
      console.error("Error sending notification:", error);
      toast.error("Failed to send notification");
    } finally {
      setIsSending(false);
    }
  };

  const fetchTutorialVideos = async () => {
    const { data, error } = await supabase
      .from("tutorial_videos")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error) setTutorialVideos(data || []);
  };

  const handleAddVideo = async () => {
    if (!newVideo.title || !newVideo.youtube_url) {
      toast.error("Please fill in title and YouTube URL");
      return;
    }

    const { error } = await supabase.from("tutorial_videos").insert([newVideo]);

    if (error) {
      toast.error("Failed to add video");
      return;
    }

    toast.success("Tutorial video added successfully!");
    setNewVideo({ title: "", youtube_url: "", description: "" });
    fetchTutorialVideos();
  };

  const handleDeleteVideo = async (id: string) => {
    const { error } = await supabase.from("tutorial_videos").delete().eq("id", id);
    if (!error) {
      toast.success("Video deleted successfully!");
      fetchTutorialVideos();
    } else {
      toast.error("Failed to delete video");
    }
  };

  const handleToggleVideoStatus = async (id: string, currentStatus: boolean) => {
    const { error } = await supabase
      .from("tutorial_videos")
      .update({ is_active: !currentStatus })
      .eq("id", id);

    if (!error) {
      toast.success("Video status updated!");
      fetchTutorialVideos();
    } else {
      toast.error("Failed to update video status");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-accent/5 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8 animate-fade-in">
          <div className="space-y-1">
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground">Manage and monitor your platform</p>
          </div>
          <Button onClick={handleLogout} variant="outline" size="lg" className="gap-2 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50 transition-all">
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 animate-fade-in">
          <Card className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent" />
            <CardHeader className="relative flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <div className="p-2 rounded-lg bg-primary/10"><Users className="h-5 w-5 text-primary" /></div>
            </CardHeader>
            <CardContent className="relative">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">{stats.totalUsers}</div>
              <p className="text-xs text-muted-foreground mt-1">Registered accounts</p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all">
            <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-accent/10 to-transparent" />
            <CardHeader className="relative flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Questions</CardTitle>
              <div className="p-2 rounded-lg bg-accent/10"><Shield className="h-5 w-5 text-accent" /></div>
            </CardHeader>
            <CardContent className="relative">
              <div className="text-4xl font-bold bg-gradient-to-r from-accent to-accent/70 bg-clip-text text-transparent">{stats.totalQuestions}</div>
              <p className="text-xs text-muted-foreground mt-1">Questions solved</p>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all">
            <div className="absolute inset-0 bg-gradient-to-br from-success/20 via-success/10 to-transparent" />
            <CardHeader className="relative flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Donations</CardTitle>
              <div className="p-2 rounded-lg bg-success/10"><DollarSign className="h-5 w-5 text-success" /></div>
            </CardHeader>
            <CardContent className="relative">
              <div className="text-4xl font-bold bg-gradient-to-r from-success to-success/70 bg-clip-text text-transparent">₹{stats.totalDonations}</div>
              <p className="text-xs text-muted-foreground mt-1">Community support</p>
            </CardContent>
          </Card>
        </div>

        {/* Settings Card */}
        <Card className="shadow-xl border-0 animate-fade-in overflow-hidden">
          <CardHeader className="border-b bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10">
            <CardTitle className="text-2xl flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10"><Shield className="w-6 h-6 text-primary" /></div>
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Platform Management</span>
            </CardTitle>
            <CardDescription className="text-base">Configure and manage all platform features</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <Tabs defaultValue="tutorials" className="space-y-6">
              <TabsList className="grid grid-cols-3 md:grid-cols-6 gap-2 bg-muted/30 p-2 rounded-xl h-auto">
                <TabsTrigger value="tutorials" className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-primary/70 data-[state=active]:text-primary-foreground py-3 rounded-lg">
                  <Video className="w-4 h-4" /><span className="hidden sm:inline">Tutorials</span>
                </TabsTrigger>
                <TabsTrigger value="notifications" className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-accent data-[state=active]:to-accent/70 data-[state=active]:text-accent-foreground py-3 rounded-lg">
                  <Bell className="w-4 h-4" /><span className="hidden sm:inline">Notifications</span>
                </TabsTrigger>
                <TabsTrigger value="social" className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-info data-[state=active]:to-info/70 data-[state=active]:text-info-foreground py-3 rounded-lg">
                  <Link2 className="w-4 h-4" /><span className="hidden sm:inline">Social</span>
                </TabsTrigger>
                <TabsTrigger value="legal" className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary data-[state=active]:to-accent data-[state=active]:text-primary-foreground py-3 rounded-lg">
                  <FileText className="w-4 h-4" /><span className="hidden sm:inline">Legal</span>
                </TabsTrigger>
                <TabsTrigger value="upi" className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-success data-[state=active]:to-success/70 data-[state=active]:text-success-foreground py-3 rounded-lg">
                  <DollarSign className="w-4 h-4" /><span className="hidden sm:inline">UPI</span>
                </TabsTrigger>
                <TabsTrigger value="donations" className="flex items-center gap-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-success data-[state=active]:to-success/70 data-[state=active]:text-success-foreground py-3 rounded-lg">
                  <DollarSign className="w-4 h-4" /><span className="hidden sm:inline">Donations</span>
                </TabsTrigger>
              </TabsList>

              {/* Tutorials Tab */}
              <TabsContent value="tutorials" className="space-y-6">
                <div className="flex items-center gap-2"><Video className="w-5 h-5 text-primary" /><h3 className="text-xl font-semibold">Tutorial Videos</h3></div>
                <Card className="border-primary/20 bg-primary/5">
                  <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Plus className="w-5 h-5" />Add New Tutorial</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="video-title">Video Title *</Label>
                      <Input id="video-title" placeholder="e.g., How to use PPU Question Solver" value={newVideo.title} onChange={(e) => setNewVideo({ ...newVideo, title: e.target.value })} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="youtube-url">YouTube URL *</Label>
                      <Input id="youtube-url" placeholder="https://www.youtube.com/watch?v=..." value={newVideo.youtube_url} onChange={(e) => setNewVideo({ ...newVideo, youtube_url: e.target.value })} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="video-description">Description (Optional)</Label>
                      <Textarea id="video-description" placeholder="Brief description" value={newVideo.description} onChange={(e) => setNewVideo({ ...newVideo, description: e.target.value })} rows={3} />
                    </div>
                    <Button onClick={handleAddVideo} className="w-full bg-gradient-to-r from-primary to-primary/80"><Plus className="w-4 h-4 mr-2" />Add Tutorial Video</Button>
                  </CardContent>
                </Card>
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-muted-foreground">Existing Tutorials ({tutorialVideos.length})</h4>
                  {tutorialVideos.length === 0 ? (
                    <Card className="border-dashed"><CardContent className="flex flex-col items-center justify-center py-12"><Video className="w-12 h-12 text-muted-foreground mb-4" /><p className="text-muted-foreground">No tutorial videos added yet</p></CardContent></Card>
                  ) : (
                    tutorialVideos.map((video) => (
                      <Card key={video.id} className="border-border/50 hover:border-primary/50 transition-colors">
                        <CardContent className="flex items-center justify-between p-4">
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-semibold">{video.title}</h4>
                              <span className={`text-xs px-2 py-1 rounded-full ${video.is_active ? 'bg-success/10 text-success' : 'bg-muted text-muted-foreground'}`}>{video.is_active ? 'Active' : 'Inactive'}</span>
                            </div>
                            {video.description && <p className="text-sm text-muted-foreground">{video.description}</p>}
                            <a href={video.youtube_url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline flex items-center gap-1"><Youtube className="w-3 h-3" />{video.youtube_url}</a>
                          </div>
                          <div className="flex items-center gap-2 ml-4">
                            <Button variant="outline" size="sm" onClick={() => handleToggleVideoStatus(video.id, video.is_active)}>{video.is_active ? 'Deactivate' : 'Activate'}</Button>
                            <Button variant="destructive" size="sm" onClick={() => handleDeleteVideo(video.id)}><Trash2 className="w-4 h-4" /></Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>

              {/* Notifications Tab */}
              <TabsContent value="notifications" className="space-y-4">
                <div className="flex items-center gap-2"><Bell className="w-5 h-5 text-accent" /><h3 className="text-xl font-semibold">Send Notification to All Users</h3></div>
                <Card className="border-accent/20 bg-accent/5">
                  <CardContent className="pt-6 space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="notification-title">Notification Title *</Label>
                      <Input id="notification-title" placeholder="e.g., New Feature Alert" value={notificationTitle} onChange={(e) => setNotificationTitle(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="notification-message">Message *</Label>
                      <Textarea id="notification-message" placeholder="Enter your notification message..." value={notificationMessage} onChange={(e) => setNotificationMessage(e.target.value)} rows={4} />
                    </div>
                    <Button onClick={handleSendNotification} disabled={isSending} className="w-full bg-gradient-to-r from-accent to-accent/80" size="lg">
                      {isSending ? <><Bell className="w-4 h-4 mr-2 animate-pulse" />Sending...</> : <><Bell className="w-4 h-4 mr-2" />Send to All Users</>}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Social Tab */}
              <TabsContent value="social" className="space-y-4">
                <div className="flex items-center gap-2"><Link2 className="w-5 h-5 text-info" /><h3 className="text-xl font-semibold">Social Media Links</h3></div>
                <div className="space-y-2"><Label htmlFor="instagram">Instagram</Label><div className="flex gap-2"><Instagram className="w-5 h-5 text-muted-foreground mt-2" /><Input id="instagram" placeholder="Instagram URL" value={socialLinks.instagram} onChange={(e) => setSocialLinks({ ...socialLinks, instagram: e.target.value })} /></div></div>
                <div className="space-y-2"><Label htmlFor="youtube">YouTube</Label><div className="flex gap-2"><Youtube className="w-5 h-5 text-muted-foreground mt-2" /><Input id="youtube" placeholder="YouTube URL" value={socialLinks.youtube} onChange={(e) => setSocialLinks({ ...socialLinks, youtube: e.target.value })} /></div></div>
                <div className="space-y-2"><Label htmlFor="email">Email</Label><div className="flex gap-2"><Mail className="w-5 h-5 text-muted-foreground mt-2" /><Input id="email" placeholder="Contact Email" value={socialLinks.email} onChange={(e) => setSocialLinks({ ...socialLinks, email: e.target.value })} /></div></div>
                <Button onClick={handleSaveSocialLinks} className="w-full bg-gradient-to-r from-info to-info/80">Save Social Links</Button>
              </TabsContent>

              {/* Legal Tab */}
              <TabsContent value="legal" className="space-y-4">
                <div className="flex items-center gap-2"><FileText className="w-5 h-5 text-primary" /><h3 className="text-xl font-semibold">Legal Documents</h3></div>
                <div className="space-y-2"><Label htmlFor="privacy">Privacy Policy URL</Label><Input id="privacy" placeholder="Privacy Policy Link" value={legalLinks.privacyPolicy} onChange={(e) => setLegalLinks({ ...legalLinks, privacyPolicy: e.target.value })} /></div>
                <div className="space-y-2"><Label htmlFor="terms">Terms of Service URL</Label><Input id="terms" placeholder="Terms of Service Link" value={legalLinks.termsOfService} onChange={(e) => setLegalLinks({ ...legalLinks, termsOfService: e.target.value })} /></div>
                <Button onClick={handleSaveLegalLinks} className="w-full bg-gradient-to-r from-primary to-accent">Save Legal Links</Button>
              </TabsContent>

              {/* UPI Tab */}
              <TabsContent value="upi" className="space-y-4">
                <div className="flex items-center gap-2"><DollarSign className="w-5 h-5 text-primary" /><h3 className="text-xl font-semibold">UPI Payment Settings</h3></div>
                <div className="space-y-2"><Label htmlFor="upiId">UPI ID</Label><Input id="upiId" placeholder="yourname@upi" value={upiSettings.upiId} onChange={(e) => setUpiSettings({ ...upiSettings, upiId: e.target.value })} /></div>
                <div className="space-y-2"><Label htmlFor="upiName">UPI Display Name</Label><Input id="upiName" placeholder="Your Name" value={upiSettings.upiName} onChange={(e) => setUpiSettings({ ...upiSettings, upiName: e.target.value })} /></div>
                <Button onClick={handleSaveUpiSettings} className="w-full bg-gradient-to-r from-primary to-primary/80">Save UPI Settings</Button>
              </TabsContent>

              {/* Donations Tab */}
              <TabsContent value="donations" className="space-y-4">
                <div className="flex items-center gap-2"><DollarSign className="w-5 h-5 text-success" /><h3 className="text-xl font-semibold">Donation Settings</h3></div>
                <p className="text-sm text-muted-foreground">Configure UPI payment details for donations</p>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;