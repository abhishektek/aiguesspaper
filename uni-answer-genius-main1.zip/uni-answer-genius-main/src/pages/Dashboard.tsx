import { useState, useEffect } from "react";
import { Bell, HelpCircle, CheckCircle, Target, Star, Clock, Heart } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import StatsCard from "@/components/StatsCard";
import QuickActionButton from "@/components/QuickActionButton";
import BottomNav from "@/components/BottomNav";
import { useNavigate } from "react-router-dom";
import { FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const Dashboard = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [recentQuestions, setRecentQuestions] = useState<any[]>([]);
  const [stats, setStats] = useState({
    questionsAsked: 0,
    answered: 0,
    saved: 0,
  });
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    checkUser();
    fetchRecentQuestions();
    fetchNotifications();
  }, []);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/login");
    } else {
      setUser(user);
    }
  };

  const fetchRecentQuestions = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("questions_history")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(5);

    if (error) {
      console.error("Error fetching questions:", error);
      return;
    }

    setRecentQuestions(data || []);
    
    // Calculate stats
    const totalQuestions = data?.length || 0;
    const savedCount = data?.filter((q: any) => q.is_saved).length || 0;
    
    setStats({
      questionsAsked: totalQuestions,
      answered: totalQuestions,
      saved: savedCount,
    });
  };

  const fetchNotifications = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching notifications:", error);
      return;
    }

    setNotifications(data || []);
    const unread = data?.filter((n: any) => !n.is_read).length || 0;
    setUnreadCount(unread);
  };

  const handleNotificationClick = async () => {
    if (unreadCount === 0) {
      toast.info("No new notifications");
      return;
    }

    // Show notifications
    const latestNotification = notifications.find((n: any) => !n.is_read);
    if (latestNotification) {
      toast.info(latestNotification.title, {
        description: latestNotification.message,
      });

      // Mark as read
      await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("id", latestNotification.id);

      fetchNotifications();
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/login");
  };


  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header with Gradient */}
      <header className="bg-gradient-hero p-6 pb-8 rounded-b-3xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Avatar className="h-12 w-12">
              <AvatarFallback className="bg-card text-primary font-bold text-lg">
                {user?.email?.charAt(0).toUpperCase() || "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-white font-semibold text-lg">
                {user?.email?.split("@")[0] || "User"}
              </h2>
              <p className="text-white/80 text-sm">Patlipura University</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white hover:bg-white/20 relative"
              onClick={handleNotificationClick}
            >
              <Bell className="h-5 w-5" fill="currentColor" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-error text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                  {unreadCount}
                </span>
              )}
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-3">
          <StatsCard
            icon={HelpCircle}
            value={stats.questionsAsked}
            label="Questions Asked"
            iconColor="text-success bg-success/10"
          />
          <StatsCard
            icon={CheckCircle}
            value={stats.answered}
            label="Answered"
            iconColor="text-success bg-success/10"
          />
          <StatsCard
            icon={Star}
            value={stats.saved}
            label="Saved"
            iconColor="text-accent bg-accent/10"
          />
          <StatsCard
            icon={Target}
            value={stats.questionsAsked > 0 ? "100%" : "0%"}
            label="Success Rate"
            iconColor="text-destructive bg-destructive/10"
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="px-6 -mt-4">
        {/* Ask Question Card */}
        <Card 
          className="p-6 bg-gradient-accent cursor-pointer hover:shadow-lg transition-all mb-4"
          onClick={() => navigate("/ask")}
        >
          <div className="flex items-center gap-4">
            <div className="text-6xl text-white">?</div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-white mb-1">
                Ask Your Question
              </h3>
              <p className="text-white/90 text-sm">
                Get instant AI powered answers to academic questions
              </p>
            </div>
          </div>
        </Card>

        {/* Donate Card */}
        <Card 
          className="p-5 bg-gradient-to-r from-success to-success/80 cursor-pointer hover:shadow-lg transition-all mb-6"
          onClick={() => navigate("/donate")}
        >
          <div className="flex items-center gap-4">
            <div className="bg-white/20 rounded-full p-3">
              <Heart className="h-7 w-7 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-white mb-0.5">
                Support Us
              </h3>
              <p className="text-white/90 text-xs">
                Help us keep this service running for students
              </p>
            </div>
          </div>
        </Card>

        {/* Quick Actions */}
        <section className="mb-6">
          <h3 className="text-lg font-semibold text-foreground mb-3">Quick Actions</h3>
          <div className="grid grid-cols-3 gap-3">
            <QuickActionButton
              icon={HelpCircle}
              label="Ask Question"
              onClick={() => navigate("/ask")}
              variant="accent"
            />
            <QuickActionButton
              icon={Clock}
              label="My History"
              onClick={() => navigate("/history")}
            />
            <QuickActionButton
              icon={FileText}
              label="Tutorial"
              onClick={() => navigate("/tutorial")}
            />
          </div>
        </section>

        {/* Recent Questions */}
        <section>
          <h3 className="text-lg font-semibold text-foreground mb-3">
            Recent Questions
          </h3>
          {recentQuestions.length === 0 ? (
            <Card className="p-8 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground font-medium mb-1">
                No questions asked yet.
              </p>
              <p className="text-sm text-muted-foreground">
                Start by asking your first question!
              </p>
            </Card>
          ) : (
            <div className="space-y-3">
              {recentQuestions.map((q: any) => (
                <Card key={q.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground mb-1">
                        {q.question.length > 100 
                          ? q.question.substring(0, 100) + "..." 
                          : q.question}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{q.subject}</span>
                        <span>•</span>
                        <span>{new Date(q.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                    {q.is_saved && (
                      <Star className="h-4 w-4 text-accent fill-accent" />
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Sign Out Button */}
        <div className="mt-6">
          <Button 
            variant="outline" 
            className="w-full" 
            onClick={handleSignOut}
          >
            Sign Out
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default Dashboard;
