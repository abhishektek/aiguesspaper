import { ArrowLeft, GraduationCap, MoreVertical } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import BottomNav from "@/components/BottomNav";

const semesters = [
  { id: "sem1", name: "Semester 1" },
  { id: "sem2", name: "Semester 2" },
  { id: "sem3", name: "Semester 3" },
  { id: "sem4", name: "Semester 4" },
  { id: "sem5", name: "Semester 5" },
  { id: "sem6", name: "Semester 6" },
  { id: "sem7", name: "Semester 7" },
  { id: "sem8", name: "Semester 8" },
];

const SelectSemester = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { university, course } = location.state || {};

  const handleSelectSemester = (semesterId: string, semesterName: string) => {
    navigate("/select-subject", { 
      state: { 
        university,
        course,
        semester: semesterName 
      } 
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Top Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">Question Solver App (User)</h1>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Navigation Header */}
      <div className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/select-course", { state: { university } })}
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h2 className="text-xl font-semibold text-foreground">Select Semester</h2>
          </div>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="px-6 py-8">
        {university && (
          <p className="text-sm text-muted-foreground">University: {university}</p>
        )}
        {course && (
          <p className="text-sm text-muted-foreground mb-2">Course: {course}</p>
        )}
        <h3 className="text-2xl font-bold text-foreground mb-6">Select Your Semester</h3>
        
        <div className="grid grid-cols-2 gap-4 mb-8">
          {semesters.map((semester) => (
            <Card
              key={semester.id}
              className="p-5 flex flex-col items-center gap-3 cursor-pointer hover:shadow-lg transition-all active:scale-98"
              onClick={() => handleSelectSemester(semester.id, semester.name)}
            >
              <div className="bg-primary/20 rounded-lg p-3">
                <GraduationCap className="h-6 w-6 text-primary" />
              </div>
              <h4 className="text-base font-medium text-foreground text-center">{semester.name}</h4>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button
            variant="link"
            onClick={() => navigate("/select-course", { state: { university } })}
            className="text-primary"
          >
            ← Back
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default SelectSemester;
