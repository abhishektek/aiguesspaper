import { useState } from "react";
import { ArrowLeft, MoreVertical, Send } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import AnswerDisplay from "@/components/AnswerDisplay";
import BottomNav from "@/components/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const EnterQuestion = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { university, course, subject } = location.state || {};
  
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!question.trim()) {
      toast.error("Please enter your question");
      return;
    }

    setIsLoading(true);
    setAnswer("");

    try {
      const { data, error } = await supabase.functions.invoke("solve-question", {
        body: {
          university: university || "Unknown",
          course: course || "Unknown",
          subject: subject || "Unknown",
          question: question.trim(),
        },
      });

      if (error) {
        if (error.message.includes("429")) {
          toast.error("Rate limit exceeded. Please try again in a moment.");
        } else if (error.message.includes("402")) {
          toast.error("Service limit reached. Please contact support.");
        } else {
          toast.error("Failed to generate answer. Please try again.");
        }
        console.error("Error:", error);
        return;
      }

      if (data?.answer) {
        setAnswer(data.answer);
        
        // Save to history
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { error: saveError } = await supabase
            .from("questions_history")
            .insert({
              user_id: user.id,
              university: university || "Unknown",
              course: course || "Unknown",
              subject: subject || "Unknown",
              question: question.trim(),
              answer: data.answer,
            });

          if (saveError) {
            console.error("Error saving to history:", saveError);
          }
        }
        
        toast.success("Answer generated successfully!");
      }
    } catch (error) {
      console.error("Error generating answer:", error);
      toast.error("An unexpected error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Top Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">Question Solver App (User)</h1>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Navigation Header */}
      <div className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/select-subject", { state: { university, course } })}
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h2 className="text-xl font-semibold text-foreground">Enter Question</h2>
          </div>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="px-6 py-6 space-y-6">
        {/* Selection Summary */}
        <div className="bg-muted/50 rounded-lg p-4 space-y-1">
          {university && (
            <p className="text-sm text-foreground"><span className="font-medium">University:</span> {university}</p>
          )}
          {course && (
            <p className="text-sm text-foreground"><span className="font-medium">Course:</span> {course}</p>
          )}
          {subject && (
            <p className="text-sm text-foreground"><span className="font-medium">Subject:</span> {subject}</p>
          )}
        </div>

        {/* Question Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="question" className="text-base font-semibold">
              Enter Your Question
            </Label>
            <Textarea
              id="question"
              placeholder="Type your question here..."
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="min-h-[150px] resize-none"
              disabled={isLoading}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-accent text-white hover:opacity-90"
            size="lg"
            disabled={isLoading || !question.trim()}
          >
            {isLoading ? (
              "Generating Answer..."
            ) : (
              <>
                <Send className="mr-2 h-5 w-5" />
                Get Answer
              </>
            )}
          </Button>
        </form>

        {/* Answer Display */}
        {(answer || isLoading) && (
          <AnswerDisplay answer={answer} isLoading={isLoading} />
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default EnterQuestion;
