import { ArrowLeft, Bookmark } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import BottomNav from "@/components/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";

const SavedPage = () => {
  const navigate = useNavigate();
  const [savedQuestions, setSavedQuestions] = useState<any[]>([]);

  useEffect(() => {
    fetchSavedQuestions();
  }, []);

  const fetchSavedQuestions = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/login");
      return;
    }

    const { data, error } = await supabase
      .from("questions_history")
      .select("*")
      .eq("user_id", user.id)
      .eq("is_saved", true)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching saved questions:", error);
      return;
    }

    setSavedQuestions(data || []);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-gradient-hero p-6 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Saved Questions</h1>
        </div>
      </header>

      <main className="px-6 py-6">
        {savedQuestions.length === 0 ? (
          <Card className="p-8 text-center">
            <Bookmark className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground font-medium mb-1">No saved questions.</p>
            <p className="text-sm text-muted-foreground">
              Save important questions for quick access.
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {savedQuestions.map((item) => (
              <Card
                key={item.id}
                className="p-5 cursor-pointer hover:shadow-lg transition-all"
                onClick={() => navigate("/history")}
              >
                <div className="flex items-start justify-between mb-2">
                  <Badge variant="secondary" className="text-xs">
                    {item.subject}
                  </Badge>
                  <Bookmark className="h-5 w-5 text-accent fill-accent" />
                </div>
                <h3 className="font-medium text-foreground mb-2 line-clamp-2">
                  {item.question}
                </h3>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>{item.course}</span>
                  <span>•</span>
                  <span>{new Date(item.created_at).toLocaleDateString()}</span>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default SavedPage;
