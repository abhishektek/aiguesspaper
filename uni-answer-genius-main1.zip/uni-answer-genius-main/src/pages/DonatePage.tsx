import { useState } from "react";
import { ArrowLeft, Heart, CreditCard, Copy, QrCode } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BottomNav from "@/components/BottomNav";
import { toast } from "sonner";

const DonatePage = () => {
  const navigate = useNavigate();
  const [amount, setAmount] = useState("100");
  const [customAmount, setCustomAmount] = useState("");
  
  // Load UPI settings from localStorage or use defaults
  const getUpiSettings = () => {
    const savedSettings = localStorage.getItem("upiSettings");
    if (savedSettings) {
      return JSON.parse(savedSettings);
    }
    return {
      upiId: "abhishektek80@ybl",
      upiName: "PPU Question Solver"
    };
  };

  const { upiId: UPI_ID, upiName: UPI_NAME } = getUpiSettings();

  const predefinedAmounts = ["50", "100", "250", "500", "1000"];

  const handleUPIPayment = () => {
    const finalAmount = customAmount || amount;
    
    // Validate amount
    if (!finalAmount || parseFloat(finalAmount) <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    // Create UPI payment link
    const upiUrl = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(UPI_NAME)}&am=${finalAmount}&cu=INR&tn=${encodeURIComponent('Donation for PPU Question Solver')}`;
    
    // Open UPI payment app
    window.location.href = upiUrl;
    
    toast.success("Opening UPI payment app...");
  };

  const copyUPIId = () => {
    navigator.clipboard.writeText(UPI_ID);
    toast.success("UPI ID copied to clipboard!");
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-gradient-hero p-4 shadow-md">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate(-1)}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold text-white">Support Us</h1>
        </div>
      </header>

      <main className="px-6 py-6">
        <Card className="p-6 bg-gradient-to-br from-success/10 to-info/10 border-success/20 mb-6">
          <div className="text-center">
            <div className="bg-success/20 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Heart className="h-8 w-8 text-success" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">
              Help Us Grow
            </h2>
            <p className="text-sm text-muted-foreground">
              Your donation helps us provide free academic assistance to thousands of students
            </p>
          </div>
        </Card>

        <Tabs defaultValue="upi" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="upi">UPI Payment</TabsTrigger>
            <TabsTrigger value="manual">Manual Payment</TabsTrigger>
          </TabsList>

          <TabsContent value="upi" className="space-y-6">
            <div>
              <Label className="text-foreground font-semibold mb-3 block">
                Select Amount (₹)
              </Label>
              <div className="grid grid-cols-3 gap-3 mb-4">
                {predefinedAmounts.map((amt) => (
                  <Button
                    key={amt}
                    variant={amount === amt && !customAmount ? "default" : "outline"}
                    onClick={() => {
                      setAmount(amt);
                      setCustomAmount("");
                    }}
                    className="h-12"
                  >
                    ₹{amt}
                  </Button>
                ))}
              </div>

              <div>
                <Label htmlFor="custom-amount" className="text-sm text-muted-foreground mb-2 block">
                  Or enter custom amount
                </Label>
                <Input
                  id="custom-amount"
                  type="number"
                  placeholder="Enter amount"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  className="h-12 text-lg"
                  min="1"
                />
              </div>
            </div>

            <Card className="p-4 bg-success/10 border-success/20">
              <div className="flex items-start gap-3">
                <QrCode className="h-5 w-5 text-success mt-1" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground mb-1">
                    Instant UPI Payment
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Pay securely using Google Pay, PhonePe, Paytm or any UPI app
                  </p>
                </div>
              </div>
            </Card>

            <Button 
              onClick={handleUPIPayment}
              className="w-full h-14 text-lg bg-gradient-to-r from-success to-success/80 hover:from-success/90 hover:to-success/70"
              size="lg"
            >
              <Heart className="mr-2 h-5 w-5" />
              Pay ₹{customAmount || amount} via UPI
            </Button>

            <p className="text-xs text-center text-muted-foreground">
              You will be redirected to your UPI app to complete the payment
            </p>
          </TabsContent>

          <TabsContent value="manual" className="space-y-6">
            <Card className="p-6 bg-gradient-to-br from-primary/5 to-accent/5">
              <div className="text-center mb-4">
                <div className="bg-primary/10 rounded-full p-3 w-14 h-14 mx-auto mb-3 flex items-center justify-center">
                  <QrCode className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">UPI ID</h3>
                <div className="bg-background rounded-lg p-4 mb-3">
                  <p className="text-xl font-mono font-bold text-primary break-all">
                    {UPI_ID}
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={copyUPIId}
                  className="gap-2"
                >
                  <Copy className="h-4 w-4" />
                  Copy UPI ID
                </Button>
              </div>
            </Card>

            <Card className="p-4 bg-info/10 border-info/20">
              <p className="text-sm text-foreground">
                <strong>How to pay manually:</strong>
              </p>
              <ol className="text-xs text-muted-foreground mt-2 space-y-1 list-decimal list-inside">
                <li>Open your UPI app (Google Pay, PhonePe, Paytm, etc.)</li>
                <li>Click on "Send Money" or "Pay"</li>
                <li>Enter the UPI ID: <span className="font-mono font-semibold">{UPI_ID}</span></li>
                <li>Enter the amount you want to donate</li>
                <li>Complete the payment</li>
              </ol>
            </Card>

            <div>
              <Label className="text-foreground font-semibold mb-3 block">
                Suggested Amounts
              </Label>
              <div className="grid grid-cols-3 gap-3">
                {predefinedAmounts.map((amt) => (
                  <Card 
                    key={amt}
                    className="p-3 text-center cursor-default hover:bg-muted/50 transition-colors"
                  >
                    <p className="text-lg font-bold text-primary">₹{amt}</p>
                  </Card>
                ))}
              </div>
            </div>

            <p className="text-xs text-center text-muted-foreground">
              After payment, you'll receive a confirmation in your UPI app
            </p>
          </TabsContent>
        </Tabs>

        <Card className="p-4 bg-muted/50 mt-6">
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <CreditCard className="h-5 w-5" />
            <p>All donations are voluntary and non-refundable. Thank you for your support!</p>
          </div>
        </Card>
      </main>

      <BottomNav />
    </div>
  );
};

export default DonatePage;
