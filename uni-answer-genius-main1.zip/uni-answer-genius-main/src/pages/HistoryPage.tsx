import { useState, useEffect } from "react";
import { ArrowLeft, FileText, Star, Bookmark } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import BottomNav from "@/components/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const HistoryPage = () => {
  const navigate = useNavigate();
  const [questions, setQuestions] = useState<any[]>([]);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/login");
      return;
    }

    const { data, error } = await supabase
      .from("questions_history")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching history:", error);
      return;
    }

    setQuestions(data || []);
  };

  const toggleSave = async (id: string, currentSaveState: boolean) => {
    const { error } = await supabase
      .from("questions_history")
      .update({ is_saved: !currentSaveState })
      .eq("id", id);

    if (error) {
      toast.error("Failed to update save status");
      return;
    }

    toast.success(currentSaveState ? "Removed from saved" : "Saved successfully");
    fetchHistory();
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-gradient-hero p-6 rounded-b-3xl">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-2xl font-bold text-white">My History</h1>
        </div>
      </header>

      <main className="px-6 py-6">
        {questions.length === 0 ? (
          <Card className="p-8 text-center">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground font-medium mb-1">No history yet.</p>
            <p className="text-sm text-muted-foreground">
              Your question history will appear here.
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {questions.map((q: any) => (
              <Card key={q.id} className="p-4">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground mb-2">
                      {q.question}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3">
                      <span>{q.subject}</span>
                      <span>•</span>
                      <span>{q.course}</span>
                      <span>•</span>
                      <span>{new Date(q.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => toggleSave(q.id, q.is_saved)}
                    className="flex-shrink-0"
                  >
                    <Bookmark
                      className={`h-5 w-5 ${
                        q.is_saved ? "text-accent fill-accent" : "text-muted-foreground"
                      }`}
                    />
                  </Button>
                </div>
                <div className="bg-muted/50 rounded-lg p-3 text-sm text-foreground">
                  <p className="whitespace-pre-wrap line-clamp-3">{q.answer}</p>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default HistoryPage;
