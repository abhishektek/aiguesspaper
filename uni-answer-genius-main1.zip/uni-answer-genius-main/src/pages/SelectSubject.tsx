import { ArrowLeft, BookMarked, MoreVertical } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import BottomNav from "@/components/BottomNav";

// Course-specific subjects with semester mapping (PPU University standards)
const courseSubjects: { [key: string]: { [key: string]: { id: string; name: string }[] } } = {
  "B.A": {
    "Semester 1": [
      { id: "hindi-1", name: "Hindi Literature - I" },
      { id: "english-1", name: "English Literature - I" },
      { id: "history-1", name: "History of India (Ancient)" },
      { id: "political-science-1", name: "Political Science - I" },
      { id: "economics-1", name: "Micro Economics" },
      { id: "sociology-1", name: "Introduction to Sociology" },
    ],
    "Semester 2": [
      { id: "hindi-2", name: "Hindi Literature - II" },
      { id: "english-2", name: "English Literature - II" },
      { id: "history-2", name: "History of India (Medieval)" },
      { id: "political-science-2", name: "Political Science - II" },
      { id: "economics-2", name: "Macro Economics" },
      { id: "sociology-2", name: "Sociology of India" },
    ],
    "Semester 3": [
      { id: "hindi-3", name: "Hindi Literature - III" },
      { id: "english-3", name: "English Literature - III" },
      { id: "history-3", name: "History of India (Modern)" },
      { id: "geography-1", name: "Physical Geography" },
      { id: "philosophy-1", name: "Indian Philosophy" },
      { id: "psychology-1", name: "Introduction to Psychology" },
    ],
    "Semester 4": [
      { id: "hindi-4", name: "Hindi Literature - IV" },
      { id: "english-4", name: "English Literature - IV" },
      { id: "history-4", name: "World History" },
      { id: "geography-2", name: "Human Geography" },
      { id: "philosophy-2", name: "Western Philosophy" },
      { id: "economics-3", name: "Indian Economy" },
    ],
    "Semester 5": [
      { id: "hindi-5", name: "Hindi Literature - V" },
      { id: "english-5", name: "English Literature - V" },
      { id: "political-science-3", name: "International Relations" },
      { id: "sociology-3", name: "Social Problems" },
      { id: "psychology-2", name: "Applied Psychology" },
      { id: "public-administration", name: "Public Administration" },
    ],
    "Semester 6": [
      { id: "hindi-6", name: "Hindi Literature - VI" },
      { id: "english-6", name: "English Literature - VI" },
      { id: "history-5", name: "History of Europe" },
      { id: "philosophy-3", name: "Logic and Ethics" },
      { id: "political-science-4", name: "Comparative Government" },
      { id: "economics-4", name: "Development Economics" },
    ],
  },
  "B.Sc": {
    "Semester 1": [
      { id: "physics-1", name: "Mechanics" },
      { id: "chemistry-1", name: "Inorganic Chemistry - I" },
      { id: "mathematics-1", name: "Calculus & Differential Equations" },
      { id: "computer-science-1", name: "Programming in C" },
      { id: "biology-1", name: "Cell Biology" },
    ],
    "Semester 2": [
      { id: "physics-2", name: "Electricity & Magnetism" },
      { id: "chemistry-2", name: "Organic Chemistry - I" },
      { id: "mathematics-2", name: "Algebra & Trigonometry" },
      { id: "computer-science-2", name: "Data Structures" },
      { id: "biology-2", name: "Genetics" },
    ],
    "Semester 3": [
      { id: "physics-3", name: "Thermodynamics & Kinetic Theory" },
      { id: "chemistry-3", name: "Physical Chemistry - I" },
      { id: "mathematics-3", name: "Real Analysis" },
      { id: "electronics-1", name: "Analog Electronics" },
      { id: "botany-1", name: "Plant Physiology" },
      { id: "zoology-1", name: "Animal Diversity" },
    ],
    "Semester 4": [
      { id: "physics-4", name: "Optics & Waves" },
      { id: "chemistry-4", name: "Inorganic Chemistry - II" },
      { id: "mathematics-4", name: "Linear Algebra & Vector Calculus" },
      { id: "electronics-2", name: "Digital Electronics" },
      { id: "botany-2", name: "Plant Anatomy" },
      { id: "zoology-2", name: "Animal Physiology" },
    ],
    "Semester 5": [
      { id: "physics-5", name: "Quantum Mechanics" },
      { id: "chemistry-5", name: "Organic Chemistry - II" },
      { id: "mathematics-5", name: "Probability & Statistics" },
      { id: "computer-science-3", name: "Database Management" },
      { id: "environmental-science", name: "Environmental Science" },
    ],
    "Semester 6": [
      { id: "physics-6", name: "Solid State Physics" },
      { id: "chemistry-6", name: "Physical Chemistry - II" },
      { id: "mathematics-6", name: "Numerical Methods" },
      { id: "computer-science-4", name: "Computer Networks" },
      { id: "project", name: "Project Work" },
    ],
  },
  "B.Com": {
    "Semester 1": [
      { id: "financial-accounting-1", name: "Financial Accounting - I" },
      { id: "business-economics-1", name: "Business Economics - I (Micro)" },
      { id: "business-law-1", name: "Business Law" },
      { id: "business-communication", name: "Business Communication" },
      { id: "business-environment", name: "Business Environment" },
    ],
    "Semester 2": [
      { id: "financial-accounting-2", name: "Financial Accounting - II" },
      { id: "business-economics-2", name: "Business Economics - II (Macro)" },
      { id: "business-mathematics", name: "Business Mathematics" },
      { id: "company-law", name: "Company Law" },
      { id: "principles-of-management", name: "Principles of Management" },
    ],
    "Semester 3": [
      { id: "corporate-accounting", name: "Corporate Accounting" },
      { id: "income-tax-1", name: "Income Tax Law & Practice - I" },
      { id: "cost-accounting-1", name: "Cost Accounting - I" },
      { id: "banking-law", name: "Banking Law & Practice" },
      { id: "business-statistics", name: "Business Statistics" },
    ],
    "Semester 4": [
      { id: "cost-accounting-2", name: "Cost Accounting - II" },
      { id: "income-tax-2", name: "Income Tax Law & Practice - II" },
      { id: "marketing-management", name: "Marketing Management" },
      { id: "financial-management", name: "Financial Management" },
      { id: "computer-applications", name: "Computer Applications in Business" },
    ],
    "Semester 5": [
      { id: "auditing", name: "Auditing & Corporate Governance" },
      { id: "gst", name: "Goods & Services Tax (GST)" },
      { id: "management-accounting", name: "Management Accounting" },
      { id: "human-resource-management", name: "Human Resource Management" },
      { id: "investment-management", name: "Investment Management" },
    ],
    "Semester 6": [
      { id: "advanced-accounting", name: "Advanced Accounting" },
      { id: "entrepreneurship", name: "Entrepreneurship Development" },
      { id: "e-commerce", name: "E-Commerce & Digital Marketing" },
      { id: "project-work", name: "Project Work" },
      { id: "business-ethics", name: "Business Ethics & CSR" },
    ],
  },
};

const SelectSubject = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { university, course, semester } = location.state || {};

  // Get subjects based on course and semester
  const subjects = courseSubjects[course]?.[semester] || [
    { id: "general", name: "General Subject" },
    { id: "other", name: "Other Subject" },
  ];

  const handleSelectSubject = (subjectId: string, subjectName: string) => {
    navigate("/enter-question", { 
      state: { 
        university,
        course,
        semester,
        subject: subjectName 
      } 
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Top Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">Question Solver App (User)</h1>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Navigation Header */}
      <div className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/select-semester", { state: { university, course } })}
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <h2 className="text-xl font-semibold text-foreground">Select Subject</h2>
          </div>
          <Button variant="ghost" size="icon">
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="px-6 py-8">
        {university && (
          <p className="text-sm text-muted-foreground">University: {university}</p>
        )}
        {course && (
          <p className="text-sm text-muted-foreground">Course: {course}</p>
        )}
        {semester && (
          <p className="text-sm text-muted-foreground mb-2">Semester: {semester}</p>
        )}
        <h3 className="text-2xl font-bold text-foreground mb-6">Select Your Subject</h3>
        
        <div className="space-y-4 mb-8">
          {subjects.map((subject) => (
            <Card
              key={subject.id}
              className="p-5 flex items-center gap-4 cursor-pointer hover:shadow-lg transition-all active:scale-98"
              onClick={() => handleSelectSubject(subject.id, subject.name)}
            >
              <div className="bg-success/20 rounded-lg p-3">
                <BookMarked className="h-6 w-6 text-success" />
              </div>
              <h4 className="text-lg font-medium text-foreground">{subject.name}</h4>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button
            variant="link"
            onClick={() => navigate("/select-semester", { state: { university, course } })}
            className="text-primary"
          >
            ← Back
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default SelectSubject;
