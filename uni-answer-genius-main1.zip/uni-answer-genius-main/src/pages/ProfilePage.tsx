import { ArrowLeft, LogOut, Instagram, Youtube, Mail, FileText, Shield } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import BottomNav from "@/components/BottomNav";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const ProfilePage = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [socialLinks, setSocialLinks] = useState({ instagram: "", youtube: "", email: "" });
  const [legalLinks, setLegalLinks] = useState({ privacyPolicy: "", termsOfService: "" });

  useEffect(() => {
    checkUser();
    loadLinks();
  }, []);

  const loadLinks = () => {
    const savedSocialLinks = localStorage.getItem("socialLinks");
    const savedLegalLinks = localStorage.getItem("legalLinks");
    
    if (savedSocialLinks) {
      setSocialLinks(JSON.parse(savedSocialLinks));
    }
    if (savedLegalLinks) {
      setLegalLinks(JSON.parse(savedLegalLinks));
    }
  };

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/login");
    } else {
      setUser(user);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out successfully");
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <header className="bg-gradient-hero p-6 rounded-b-3xl">
        <div className="flex items-center gap-3 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-6 w-6" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Profile</h1>
        </div>

        <div className="flex flex-col items-center">
          <Avatar className="h-24 w-24 mb-3">
            <AvatarFallback className="bg-card text-primary font-bold text-3xl">
              {user?.email?.charAt(0).toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <h2 className="text-white font-semibold text-xl">
            {user?.email?.split("@")[0] || "User"}
          </h2>
          <p className="text-white/80 text-sm">{user?.email || ""}</p>
        </div>
      </header>

      <main className="px-6 py-6 space-y-4">
        {/* Social Media Links */}
        <Card className="p-4">
          <h3 className="font-semibold text-foreground mb-3">Connect With Us</h3>
          <div className="space-y-2">
            {socialLinks.instagram && (
              <Button
                variant="outline"
                className="w-full justify-start gap-3"
                onClick={() => window.open(socialLinks.instagram, "_blank")}
              >
                <Instagram className="h-5 w-5 text-pink-500" />
                Instagram
              </Button>
            )}
            {socialLinks.youtube && (
              <Button
                variant="outline"
                className="w-full justify-start gap-3"
                onClick={() => window.open(socialLinks.youtube, "_blank")}
              >
                <Youtube className="h-5 w-5 text-red-500" />
                YouTube
              </Button>
            )}
            {socialLinks.email && (
              <Button
                variant="outline"
                className="w-full justify-start gap-3"
                onClick={() => window.open(`mailto:${socialLinks.email}`)}
              >
                <Mail className="h-5 w-5 text-blue-500" />
                Contact Us
              </Button>
            )}
          </div>
        </Card>

        {/* Legal Links */}
        <Card className="p-4">
          <h3 className="font-semibold text-foreground mb-3">Legal</h3>
          <div className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-start gap-3"
              onClick={() => {
                if (legalLinks.privacyPolicy) {
                  window.open(legalLinks.privacyPolicy, "_blank");
                } else {
                  toast.info("Privacy Policy link not configured");
                }
              }}
            >
              <Shield className="h-5 w-5" />
              Privacy Policy
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start gap-3"
              onClick={() => {
                if (legalLinks.termsOfService) {
                  window.open(legalLinks.termsOfService, "_blank");
                } else {
                  toast.info("Terms of Service link not configured");
                }
              }}
            >
              <FileText className="h-5 w-5" />
              Terms of Service
            </Button>
          </div>
        </Card>

        {/* Logout */}
        <Button
          variant="destructive"
          className="w-full gap-2"
          onClick={handleSignOut}
        >
          <LogOut className="h-5 w-5" />
          Logout
        </Button>
      </main>

      <BottomNav />
    </div>
  );
};

export default ProfilePage;
